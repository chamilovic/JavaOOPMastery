# Java OOP Mastery — Android source project

Native Android application written in Java. Includes a dark learning dashboard, 12-topic OOP path, structured explanations and code examples, knowledge checks with explanations, local SQLite progress tracking, review screens, and an offline code-snippet notebook.

## Important: Java execution
The current Code Lab is an offline editor/notebook. It does not claim to compile or execute Java. A genuine offline Java execution engine on Android needs a compatible Java compiler plus bytecode-to-Dex/runtime integration and sandboxing. That engine is not included in this source package; no simulated output is shown.

## Build APK using only your phone
1. Extract this ZIP.
2. Create a GitHub repository named `JavaOOPMastery`.
3. Upload the contents of this folder to the repository root.
4. Open **Actions** → **Build Android APK** → **Run workflow** (or push to `main`).
5. Open the completed run → **Artifacts** → download `Java-OOP-Mastery-debug`.
6. Extract the artifact ZIP and install `app-debug.apk`. Allow installs from your browser/file manager when Android asks.

Cloud build uses JDK 17, Gradle 8.7 and Android Gradle Plugin 8.6.1. Minimum Android API is 23; Android 9 is supported. No internet permission is declared in the app; lessons and progress are local.
