# Status — source package 1.0.0
Implemented: native Java Android app, dark UI, 12-topic learning path, structured lesson explanations and examples, 3-question checks for every topic with answer explanations, SQLite progress, review/progress screens, offline code snippet notebook, GitHub Actions cloud APK build.
Not implemented: genuine offline Java compile/run engine, syntax-aware editor, spaced-repetition scheduler, guided project missions and static code analysis. These are explicitly not simulated.
